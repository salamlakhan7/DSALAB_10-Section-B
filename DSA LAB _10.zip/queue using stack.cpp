#include <iostream>
#include <stack>
using namespace std;

class Queue {
private:
    stack<int> s1, s2;
public:
    void enqueue(int item) {
        s1.push(item);
        cout << "Item enqueued: " << item << endl;
    }
    
    void dequeue() {
        if (s1.empty() && s2.empty()) {
            cout << "Queue is empty." << endl;
            return;
        }
        
        if (s2.empty()) {
            while (!s1.empty()) {
                s2.push(s1.top());
                s1.pop();
            }
        }
        
        int front = s2.top();
        s2.pop();
        
        cout << "Item dequeued: " << front << endl;
    }
    
    void display() {
        if (s1.empty() && s2.empty()) {
            cout << "Queue is empty." << endl;
            return;
        }
        
        cout << "Elements in the queue: ";
        
        while (!s2.empty()) {
            cout << s2.top() << " ";
            s2.pop();
        }
        
        stack<int> temp = s1;
        
        while (!temp.empty()) {
            s2.push(temp.top());
            temp.pop();
        }
        
        while (!s2.empty()) {
            cout << s2.top() << " ";
            s2.pop();
        }
        
        cout << endl;
    }
};

int main() {
    Queue q;
    
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    
    q.display();
    
    q.dequeue();
    
    q.display();
    
    return 0;
}

