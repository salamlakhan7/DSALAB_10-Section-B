#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class CircularQueue {
private:
    Node* front;
    Node* rear;
public:
    CircularQueue() {
        front = rear = NULL;
    }
    
    bool isEmpty() {
        return (front == NULL);
    }
    
    void enqueue(int item) {
        Node* newNode = new Node;
        newNode->data = item;
        newNode->next = NULL;
        
        if (isEmpty()) {
            front = rear = newNode;
            rear->next = front; // connecting last node to first node
        } else {
            rear->next = newNode;
            rear = newNode;
            rear->next = front; // connecting last node to first node
        }
        
        cout << "Item enqueued: " << item << endl;
    }
    
    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        } else if (front == rear) {
            Node* temp = front;
            front = rear = NULL;
            delete temp;
        } else {
            Node* temp = front;
            front = front->next;
            rear->next = front; // connecting last node to first node
            delete temp;
        }
        
        cout << "Item dequeued." << endl;
    }
    
    void display() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        }
        
        Node* temp = front;
        cout << "Elements in the circular queue: ";
        while (temp->next != front) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << temp->data << endl;
    }
};

int main() {
    CircularQueue cq;
    
    cq.enqueue(10);
    cq.enqueue(20);
    cq.enqueue(30);
    
    cq.display();
    
    cq.dequeue();
    
    cq.display();
    
    return 0;
}


//I hope this helps you! Let me know if you have any other questions.
