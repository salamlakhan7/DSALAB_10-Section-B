#include <iostream>
#include <queue>
using namespace std;

class Stack {
private:
    queue<int> q1, q2;
public:
    void push(int item) {
        q2.push(item);
        while (!q1.empty()) {
            q2.push(q1.front());
            q1.pop();
        }
        swap(q1, q2);
        cout << "Item pushed: " << item << endl;
    }
    
    void pop() {
        if (q1.empty()) {
            cout << "Stack is empty." << endl;
            return;
        }
        int top = q1.front();
        q1.pop();
        cout << "Item popped: " << top << endl;
    }
    
    void display() {
        if (q1.empty()) {
            cout << "Stack is empty." << endl;
            return;
        }
        cout << "Elements in the stack: ";
        queue<int> temp = q1;
        while (!temp.empty()) {
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    }
};

int main() {
    Stack s;
    
    s.push(10);
    s.push(20);
    s.push(30);
    
    s.display();
    
    s.pop();
    
    s.display();
    
    return 0;
}

